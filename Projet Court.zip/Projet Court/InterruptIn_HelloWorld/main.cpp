#include "mbed.h"
 
PwmOut E1(p22);
PwmOut E2(p23);
PwmOut M1(p21);
PwmOut M2(p24);
InterruptIn button(D3);
DigitalOut led(LED1);
DigitalOut flash(LED4);

AnalogIn photoresistor1(p20);
AnalogIn photoresistor2(p19);
AnalogIn photoresistor3(p18);
AnalogIn photoresistor4(p17);
AnalogIn photoresistor5(p16);

Serial pc(USBTX, USBRX);
 
int main() {
		
	E1 = 0.2f;
	E2 = 0.2f;
	M1 = 0;
	M2 = 1;
	
	while(1){
		
		
		float vol1 = photoresistor1.read();
		float vol2 = photoresistor2.read();
		float vol3 = photoresistor3.read();
		float vol4 = photoresistor4.read();
		float vol5 = photoresistor5.read();
		/*if (vol1 == vol2) {
			E1 = 0.8f;
			E2 = 0.8f;
		} else if (vol1 > vol2){
			E1 = 0.0f;
			E2 = 0.8f;
		} else {
			E1 = 0.8f;
			E2 = 0.0f;
		}*/
		pc.printf("Vol 1 : %.2f V\r\n", vol1);
		//pc.printf("Vol 2 : %.2f V\r\n", vol2);
		//pc.printf("Vol 3 : %.2f V\r\n", vol3);
		//pc.printf("Vol 4 : %.2f V\r\n", vol4);
		//pc.printf("Vol 5 : %.2f V\r\n", vol5);
		wait(0.5);
		//E1 = 0.8f;
		//E2 = 0.8f;
		
	}
	
}
